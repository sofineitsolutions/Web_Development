-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 15, 2020 at 10:48 AM
-- Server version: 5.5.24
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nilesh`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE IF NOT EXISTS `about` (
  `name` text NOT NULL,
  `m2` text NOT NULL,
  `name3` text NOT NULL,
  `des` text NOT NULL,
  `twitter` text NOT NULL,
  `facebook` text NOT NULL,
  `instagram` text NOT NULL,
  `theme1` text NOT NULL,
  `count1` text NOT NULL,
  `theme2` text NOT NULL,
  `theme3` text NOT NULL,
  `theme4` text NOT NULL,
  `follow` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`name`, `m2`, `name3`, `des`, `twitter`, `facebook`, `instagram`, `theme1`, `count1`, `theme2`, `theme3`, `theme4`, `follow`) VALUES
('My Name is Nilesh Rane', 'Nice To Meet You', 'My Name is Nilesh Rane', 'Sports helps build talent and hobbies so that the people can be better at delivering them for personal and professional purposes. Sports also serve as a good leisure activity meant to relieve one from physical and emotional stress hence a healthy living.', 'https://twitter.com/nileshranem', 'https://www.facebook.com/ranenileshsports/', 'https://www.instagram.com/nileshrane_sports/?hl=en', 'Pounds of Equipment', '0', 'Studio Session', 'Finished Photosessions', 'Happy Clients', 'Follow me on Instagram');

-- --------------------------------------------------------

--
-- Table structure for table `home`
--

CREATE TABLE IF NOT EXISTS `home` (
  `Name` text NOT NULL,
  `title1` text NOT NULL,
  `title2` text NOT NULL,
  `title3` text NOT NULL,
  `des` text NOT NULL,
  `des1` text NOT NULL,
  `read` text NOT NULL,
  `twitter` text NOT NULL,
  `facebook` text NOT NULL,
  `instagram` text NOT NULL,
  `follow` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `home`
--

INSERT INTO `home` (`Name`, `title1`, `title2`, `title3`, `des`, `des1`, `read`, `twitter`, `facebook`, `instagram`, `follow`) VALUES
('u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u'),
('l', 'l', 'j', 'j', 'j', 'jh', 'h', 'hh', 'h', 'hh', 'h');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE IF NOT EXISTS `services` (
  `Services` text NOT NULL,
  `Services1` text NOT NULL,
  `event1` text NOT NULL,
  `des1` text NOT NULL,
  `event2` text NOT NULL,
  `des2` text NOT NULL,
  `event3` text NOT NULL,
  `des3` text NOT NULL,
  `event4` text NOT NULL,
  `des4` text NOT NULL,
  `event5` text NOT NULL,
  `des5` text NOT NULL,
  `event6` text NOT NULL,
  `des6` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`Services`, `Services1`, `event1`, `des1`, `event2`, `des2`, `event3`, `des3`, `event4`, `des4`, `event5`, `des5`, `event6`, `des6`) VALUES
('Services', 'My Services', 'State level event', 'A small river named Duden flows by their place and supplies.', 'International Event', 'A small river named Duden flows by their place and supplies.', 'Social Work', 'A small river named Duden flows by their place and supplies.', 'Political Work', 'A small river named Duden flows by their place and supplies.', 'Sport Activity', 'A small river named Duden flows by their place and supplies.', 'Motivational Speaker', 'A small river named Duden flows by their place and supplies.');
